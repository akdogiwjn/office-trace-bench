----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-10-08 9:19 pm CDT
----------------------------------------------------------------

------  --------------------------------------------------------------------  ------------------------
AMTMVS  Manufacturers' Value of Shipments: Total Manufacturing, Millions of   Data Updated: 2026-10-02
        Dollars, Monthly, Seasonally Adjusted
AMTMNO  Manufacturers' New Orders: Total Manufacturing, Millions of Dollars,  Data Updated: 2026-10-02
        Monthly, Seasonally Adjusted
AMTMUO  Manufacturers' Unfilled Orders: Total Manufacturing, Millions of      Data Updated: 2026-10-02
        Dollars, Monthly, Seasonally Adjusted
AMTMTI  Manufacturers' Total Inventories: Total Manufacturing, Millions of    Data Updated: 2026-10-02
        Dollars, Monthly, Seasonally Adjusted
------  --------------------------------------------------------------------  ------------------------

